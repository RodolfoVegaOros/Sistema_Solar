# planet-ring-mesh
Files from the Board To Bits planet ring mesh tutorial. https://youtu.be/Rze4GEFrYYs
